﻿using System;
using System.IO;
using OpenBveApi.Runtime;
using System;
 using System.Collections.Generic;
 using System.IO;
 using System.Linq;
 using System.Threading;
 using System.Threading.Tasks;


namespace OpenBVETrainPlugin
{
    public class TrainPlugin : IRuntime
    {
        // Path to log the datad
        private string logFilePath;
        public bool IsPressedS;
        public bool IsPressedA1;
        // This method initializes the plugin and is called once when the train is loaded
        public bool Load(LoadProperties properties)
        {
            // Set the log file path to the user's Documents folder or a local folder
            string documentsFolder = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            logFilePath = Path.Combine(documentsFolder, "OpenBVE_Train_Data", "train_data_log.csv");

            // Create the directory if it doesn't exist
            Directory.CreateDirectory(Path.GetDirectoryName(logFilePath));

            // Create the log file if it doesn't exist, and write the header
            if (!File.Exists(logFilePath))
            {
                File.WriteAllText(logFilePath, "TotalTime,Speed(km/h),PowerNotch,BrakeNotch,AWS,A1Alert\n");
            }

            // Optionally, log train properties here
            properties.AISupport = AISupport.None; // Disable AI support

            // Return true to indicate the plugin has loaded successfully
            return true;
        }

        // Called when the simulation starts
        public void Initialize(InitializationModes mode)
        {
            // Initialize any resources or variables if needed
        }

        // Called each frame to retrieve data
        public void Elapse(ElapseData data)
        {
            // Capture data
            double speed = data.Vehicle.Speed.KilometersPerHour;
            int powerNotch = data.Handles.PowerNotch;
            int brakeNotch = data.Handles.BrakeNotch;
            double totalTime = data.TotalTime.Seconds;  // Elapsed time in milliseconds
            bool IsPressedS2 = IsPressedS;
            // Log data to CSV
            string logLine = $"{totalTime},{speed},{powerNotch},{brakeNotch},{IsPressedS2},{IsPressedA1}";
            File.AppendAllText(logFilePath, logLine + Environment.NewLine);
        }

        public void SetPower(int notch) { }
        public void SetBrake(int notch) { }
        public void SetReverser(int position) { }
        public void KeyDown(VirtualKeys key) {
            if(key == VirtualKeys.S){
                IsPressedS = true;
            }
            if(key == VirtualKeys.A1){
                IsPressedA1 = true;
            }
         }
        public void KeyUp(VirtualKeys key) { 
            if(key == VirtualKeys.S){
                IsPressedS = false;
            }
            if(key == VirtualKeys.A1){
                IsPressedA1 = false;
            }
        }
        public void DoorChange(DoorStates oldState, DoorStates newState) { }
        public void HornBlow(HornTypes type) { }
        public void SetSignal(SignalData[] signal) { }
        public void SetBeacon(BeaconData beacon) { }
        public void SetVehicleSpecs(VehicleSpecs specs) { }
        public void PerformAI(AIData data) { }
        public void Unload() { }
    }
}
