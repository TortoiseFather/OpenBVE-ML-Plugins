## Editing Language Files
As of openBVE v1.7.0 the language data files are stored in XLF (XML Localization Interchange File Format) format.
<https://en.wikipedia.org/wiki/XLIFF>

This is intended to allow for easier editing, as well as support for translations in the viewers etc.

Whilst XLF files may still be edited manually, we suggest using an XLF GUI editor such as POEdit:
<https://en.wikipedia.org/wiki/XLIFF>